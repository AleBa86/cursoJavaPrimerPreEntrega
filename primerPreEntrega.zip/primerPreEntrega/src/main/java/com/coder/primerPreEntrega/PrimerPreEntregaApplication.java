package com.coder.primerPreEntrega;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrimerPreEntregaApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrimerPreEntregaApplication.class, args);
	}

}
